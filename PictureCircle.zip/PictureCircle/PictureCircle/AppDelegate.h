//
//  AppDelegate.h
//  PictureCircle
//
//  Created by 110 on 16/6/20.
//  Copyright © 2016年 JiKe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

