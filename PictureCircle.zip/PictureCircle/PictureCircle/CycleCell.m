//
//  CycleCell.m
//  PictureCircle
//
//  Created by 110 on 16/6/20.
//  Copyright © 2016年 JiKe. All rights reserved.
//

#import "CycleCell.h"

@interface CycleCell ()
@property (weak, nonatomic) IBOutlet UIImageView *iconImage;
@end

@implementation CycleCell

/*
 *后续可以使用SDWebImage加载网络图片
 */
- (void)setImageURL:(NSURL *)imageURL{
    
    _imageURL = imageURL;
    NSData *data = [NSData dataWithContentsOfURL:imageURL];
    UIImage *image = [UIImage imageWithData:data];
    self.iconImage.image = image;
    
}

@end
