//
//  CycleViewController.m
//  PictureCircle
//
//  Created by 110 on 16/6/20.
//  Copyright © 2016年 JiKe. All rights reserved.
//

#import "CycleViewController.h"
#import "CycleCell.h"

#define kScreenW [UIScreen mainScreen].bounds.size.width
#define kScreenH [UIScreen mainScreen].bounds.size.height

@interface CycleViewController ()

//流水布局
@property (weak, nonatomic) IBOutlet UICollectionViewFlowLayout *layout;
//所有图像的url数组
@property (strong, nonatomic) NSArray *imageURLs;
//当前显示的图像索引
@property (assign, nonatomic) NSInteger currentIndex;
@property (strong, nonatomic) UIPageControl *pageControl;
@property (strong, nonatomic) UIView *bgView;
@property (strong, nonatomic) NSTimer *timer;
@property (assign, nonatomic) NSInteger isEnd;

@end

@implementation CycleViewController

static NSString * const reuseIdentifier = @"Cell";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations
    // self.clearsSelectionOnViewWillAppear = NO;
    // Register cell classes
//    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];
    // Do any additional setup after loading the view.
    
    //往数组里面放图片
    [self loadData];
    
    [self.view addSubview:self.pageControl];//图片指示器
       _isEnd = 1;
   
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
    //设置布局
    self.layout.itemSize = self.view.bounds.size;
    self.layout.minimumInteritemSpacing = 0;
    self.layout.minimumLineSpacing = 0;
    //设置滚动方向
    self.layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    //允许分页
    self.collectionView.pagingEnabled = YES;
    //滚动到item == 1 的图片  设置collectionView的偏移量
    self.collectionView.contentOffset = CGPointMake(self.view.bounds.size.width, 0);
    self.collectionView.showsHorizontalScrollIndicator = NO;
    self.currentIndex = 0;
    [self addTimer];
    
}

#pragma mark -自定义方法
//添加定时器
- (void)addTimer
{
    self.timer = [NSTimer scheduledTimerWithTimeInterval:3.0 target:self selector:@selector(scrollViewPageControll) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
}

//移除定时器
- (void)removeTimer{
    [self.timer invalidate];//使定时器无效
    self.timer = nil;
    
}

#pragma mark - setter & getter
-(UIPageControl *)pageControl{
    if (!_pageControl) {
        _pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0,kScreenH-50, kScreenW, 50)];
        _pageControl.numberOfPages = self.imageURLs.count;
        _pageControl.currentPage = 0;
        _pageControl.currentPageIndicatorTintColor = [UIColor greenColor];
        _pageControl.pageIndicatorTintColor = [UIColor whiteColor];
        [_pageControl addTarget:self action:@selector(pageControlChanged:) forControlEvents:UIControlEventValueChanged];
    }
    return _pageControl;
}


#pragma mark <UICollectionViewDataSource>
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.imageURLs.count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    CycleCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    //indexPath.item == 0 时显示的是第九张图片
    //indexPath.item == 1 时显示的是第0张图片
    //indexPath.item == 2 时显示的是第1张图片
    
    //刚开始向右滑动的时候indexPath.item是2 但调用 dispatch_async(dispatch_get_main_queue(), ^{
    //[scrollView setContentOffset:CGPointMake(scrollView.bounds.size.width, 0) animated:NO];
    //    });时indexPath.item就会变成1;   2，1    2，1    2，1    2，1
    
    //如果向左滑动的时候indexPath.item是0,但是调用dispatch_async(dispatch_get_main_queue(), ^{
    //[scrollView setContentOffset:CGPointMake(scrollView.bounds.size.width, 0) animated:NO];
    // });时indexPath.item就会变成1;      0，1    0，1    0，1    0，1
    
    //NSLog(@"indexPath.item:%ld",indexPath.item);
    NSInteger index = (indexPath.item-1+self.imageURLs.count+self.currentIndex)%self.imageURLs.count;
    cell.imageURL = self.imageURLs[index];
    return cell;
    
}


#pragma mark - UIScrollViewDelegate
//停止滚动时调用此方法
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
   
    NSInteger offset = scrollView.contentOffset.x/scrollView.bounds.size.width-1;
    //如果页面没有变化，直接返回 offset只有-1，0，1三个值
    if (offset == 0) {
        return;
    }
    //在这里 offset 只有 -1，1;向右滑一直是加+1(也就是说offset是1);向左滑一直是加-1(也就是说offset是-1)
    self.currentIndex = (self.currentIndex +offset+self.imageURLs.count)%self.imageURLs.count;
    self.pageControl.currentPage = self.currentIndex;//设置指示器的当前指示页
    //滑动结束之后indexPath.item的索引始终是1
    dispatch_async(dispatch_get_main_queue(), ^{
        [scrollView setContentOffset:CGPointMake(scrollView.bounds.size.width, 0) animated:NO];
    });
}

//开始拖拽时调用此方法
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    //移除定时器
    [self removeTimer];
}

//停止拖拽时调用此方法
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    [self addTimer];
}


#pragma mark -addTarget(pageControl绑定的方法)
- (void)pageControlChanged:(UIPageControl*)pageControl{

    [self removeTimer];
    //自动滚动到第二个item(第一种方法)
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.collectionView setContentOffset:CGPointMake(2*self.collectionView.bounds.size.width, 0) animated:YES];
    });
    
    //在动画结束后 调用停止的方法 返回第一个item
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self scrollViewDidEndDecelerating:self.collectionView];
    });

    
}

//时间定时器的方法
- (void)scrollViewPageControll{
    
//    __weak typeof(self) Self = self;
////    self.currentIndex += (_isEnd+self.imageURLs.count)%self.imageURLs.count;
////    self.pageControl.currentPage = self.currentIndex%self.imageURLs.count;//设置指示器的当前指示页
//     self.currentIndex +=_isEnd;//(左右滑)
//     self.pageControl.currentPage = self.currentIndex;
//     if (self.currentIndex ==self.imageURLs.count-1 || self.currentIndex==0) {
//        _isEnd = -_isEnd;
//     }
//    //滑动结束之后indexPath.item的索引始终是1
//    dispatch_async(dispatch_get_main_queue(), ^{
//        [Self.collectionView setContentOffset:CGPointMake(self.collectionView.bounds.size.width, 0) animated:YES];
//    });
//    [self.collectionView reloadData];
    
    
    //自动滚动到第二个item(第二种方法)
//    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:2 inSection:0];
//    [self.collectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
    
    //自动滚动到第二个item(第一种方法)
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.collectionView setContentOffset:CGPointMake(2*self.collectionView.bounds.size.width, 0) animated:YES];
    });
     //在动画结束后 调用停止的方法 返回第一个item
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self scrollViewDidEndDecelerating:self.collectionView];
    });
    
}

#pragma mark -自定义方法
//加载图片数据
- (void)loadData{
    
    NSMutableArray *arrayM = [NSMutableArray array];
    for (int i=0; i<10; i++) {
        NSString *fileName = [NSString stringWithFormat:@"%02d.jpg",i+1];
        NSURL *url = [[NSBundle mainBundle] URLForResource:fileName withExtension:nil];
        [arrayM addObject:url];
    }
    self.imageURLs = arrayM.copy;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
